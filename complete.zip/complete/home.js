import { MDCList } from '@material/list';
import { MDCTabBar } from '@material/tab-bar';
import { MDCSelect } from '@material/select';

const select = new MDCSelect(document.querySelector('.mdc-select'));

select.listen('MDCSelect:change', () => {
    const typeExamples = document.querySelectorAll(".type-scale-example");
    typeExamples.forEach(function (el) {
        debugger;
        el.style.fontFamily = select.value;
    });
});

const tabBar = new MDCTabBar(document.querySelector('.mdc-tab-bar'));
new MDCList(document.querySelector('.mdc-list'));

const buttons = document.querySelectorAll(".font-example");
buttons.forEach(function (element) {
    element.onclick = function (e) { myFunction(e) };
});


function myFunction(e) {
    const typeExamples = document.querySelectorAll(".type-scale-example");
    typeExamples.forEach(function (el) {
        el.style.fontFamily = e.currentTarget.parentNode.children[1].innerText;
    });
}